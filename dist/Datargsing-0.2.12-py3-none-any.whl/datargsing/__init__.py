# -*- coding: utf-8 -*-

"""
Datargsing Module
"""

from datargsing.datargsing import CSV_JSON_Manager as dGlobal_datafiles_manager, Tools as dTools, datargsing_Failure as dFailure, datargsing_Error as dError, datargsing_Complete as dComplete, __version__ as dVersion
