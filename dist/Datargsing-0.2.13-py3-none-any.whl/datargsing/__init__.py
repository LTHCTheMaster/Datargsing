# -*- coding: utf-8 -*-

"""
Datargsing Module
"""

from datargsing.datargsing import CSV_JSON_Manager as dGDM, Tools as dTools, datargsing_Failure as dFailure, datargsing_Error as dError, datargsing_Complete as dComplete, __version__ as dVersion
